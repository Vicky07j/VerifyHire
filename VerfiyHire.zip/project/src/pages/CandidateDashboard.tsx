import React from 'react';
import { Upload, Bell, Award } from 'lucide-react';

function CandidateDashboard() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-gradient-to-r from-indigo-900 to-purple-900 p-8">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white">Candidate Dashboard</h1>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Resume Upload */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
              <Upload className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">Upload Resume</h3>
            <p className="text-gray-600 mb-4">Upload your resume for AI analysis and job matching</p>
            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
              Upload Now
            </button>
          </div>

          {/* Job Notifications */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
              <Bell className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">Job Notifications</h3>
            <p className="text-gray-600 mb-4">Get notified when new matching jobs are posted</p>
            <button className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition-colors">
              View Matches
            </button>
          </div>

          {/* Premium Features */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-pink-500 rounded-lg flex items-center justify-center mb-4">
              <Award className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">Premium Features</h3>
            <p className="text-gray-600 mb-4">Access AI resume optimization and career guidance</p>
            <button className="bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 transition-colors">
              Upgrade Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CandidateDashboard;