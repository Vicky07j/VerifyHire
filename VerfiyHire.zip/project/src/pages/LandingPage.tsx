import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, FileCheck, Users, Video, Shield, UserCircle, Briefcase, CheckCircle } from 'lucide-react';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10" />
        <div className="container mx-auto px-4 py-16">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-white mb-6">
              VerifyHire
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
                .AI
              </span>
            </h1>
            <p className="text-xl text-gray-300 mb-12">
              AI-Powered Resume Verification & Hiring Platform
            </p>
            
            {/* User Role Selection */}
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
              <button 
                onClick={() => navigate('/candidate')}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-8 hover:transform hover:scale-105 transition-all group"
              >
                <div className="h-16 w-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-400 transition-colors">
                  <UserCircle className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">I'm a Candidate</h3>
                <p className="text-gray-300 mb-4">Upload your resume and get matched with perfect job opportunities</p>
                <span className="text-blue-400 flex items-center justify-center gap-2">
                  Get Started <ArrowRight size={20} />
                </span>
              </button>

              <button 
                onClick={() => navigate('/recruiter')}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-8 hover:transform hover:scale-105 transition-all group"
              >
                <div className="h-16 w-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-400 transition-colors">
                  <Briefcase className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">I'm a Recruiter</h3>
                <p className="text-gray-300 mb-4">Post jobs and find the perfect candidates using AI-powered matching</p>
                <span className="text-purple-400 flex items-center justify-center gap-2">
                  Get Started <ArrowRight size={20} />
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* AI Resume Verification */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 hover:transform hover:scale-105 transition-all">
            <div className="h-12 w-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
              <FileCheck className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">
              AI Resume Verification
            </h3>
            <p className="text-gray-300">
              Advanced AI algorithms analyze and verify resumes in real-time, ensuring accuracy and authenticity.
            </p>
          </div>

          {/* Smart Matching */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 hover:transform hover:scale-105 transition-all">
            <div className="h-12 w-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
              <Users className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">
              Smart Matching
            </h3>
            <p className="text-gray-300">
              Intelligent job-candidate matching using advanced algorithms and machine learning.
            </p>
          </div>

          {/* Video Interviews */}
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 hover:transform hover:scale-105 transition-all">
            <div className="h-12 w-12 bg-pink-500 rounded-lg flex items-center justify-center mb-4">
              <Video className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-3">
              AI Video Interviews
            </h3>
            <p className="text-gray-300">
              Automated video interviews with AI-powered analysis and insights.
            </p>
          </div>
        </div>
      </div>

      {/* Process Flow */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          How It Works
        </h2>
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex-1 text-center">
            <div className="h-16 w-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileCheck className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Upload Resume</h3>
            <p className="text-gray-300">Submit your resume for AI analysis</p>
          </div>
          <ArrowRight className="text-gray-500 hidden md:block" size={24} />
          <div className="flex-1 text-center">
            <div className="h-16 w-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">AI Verification</h3>
            <p className="text-gray-300">Advanced AI verifies your credentials</p>
          </div>
          <ArrowRight className="text-gray-500 hidden md:block" size={24} />
          <div className="flex-1 text-center">
            <div className="h-16 w-16 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="text-white" size={32} />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Get Matched</h3>
            <p className="text-gray-300">Connect with perfect job opportunities</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;