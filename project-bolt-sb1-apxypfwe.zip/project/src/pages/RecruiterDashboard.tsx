import React from 'react';
import { FileText, Search, Users } from 'lucide-react';

function RecruiterDashboard() {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-gradient-to-r from-indigo-900 to-purple-900 p-8">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold text-white">Recruiter Dashboard</h1>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Post Job */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
              <FileText className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">Post Job</h3>
            <p className="text-gray-600 mb-4">Create a new job posting and find matching candidates</p>
            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors">
              Create Job
            </button>
          </div>

          {/* View Applications */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
              <Search className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">View Applications</h3>
            <p className="text-gray-600 mb-4">Review and manage candidate applications</p>
            <button className="bg-purple-500 text-white px-4 py-2 rounded-lg hover:bg-purple-600 transition-colors">
              View All
            </button>
          </div>

          {/* Candidate Pool */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="h-12 w-12 bg-pink-500 rounded-lg flex items-center justify-center mb-4">
              <Users className="text-white" size={24} />
            </div>
            <h3 className="text-xl font-semibold mb-3">Candidate Pool</h3>
            <p className="text-gray-600 mb-4">Browse and search through verified candidates</p>
            <button className="bg-pink-500 text-white px-4 py-2 rounded-lg hover:bg-pink-600 transition-colors">
              Browse Pool
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RecruiterDashboard;